namespace IPTCULMI.Models
{
    public class ReturnRecord
    {
    public int ReturnRecordId { get; set; }

    public int BorrowLogId { get; set; } 

    public string BookTitle { get; set; } = string.Empty;
    public DateTime ReturnDate { get; set; }

    public BorrowLog BorrowLog { get; set; }
    }
}