﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IPTCULMI.Migrations
{
    /// <inheritdoc />
    public partial class AddReturnRecordTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ReturnRecords",
                columns: table => new
                {
                    ReturnRecordId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    BorrowLogId = table.Column<int>(type: "int", nullable: false),
                    ReturnDate = table.Column<DateTime>(type: "datetime(6)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ReturnRecords", x => x.ReturnRecordId);
                    table.ForeignKey(
                        name: "FK_ReturnRecords_BorrowLogs_BorrowLogId",
                        column: x => x.BorrowLogId,
                        principalTable: "BorrowLogs",
                        principalColumn: "BorrowLogId",
                        onDelete: ReferentialAction.Cascade);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateIndex(
                name: "IX_ReturnRecords_BorrowLogId",
                table: "ReturnRecords",
                column: "BorrowLogId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ReturnRecords");
        }
    }
}
