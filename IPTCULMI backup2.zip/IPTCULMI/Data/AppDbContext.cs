using Microsoft.EntityFrameworkCore;
using IPTCULMI.Models;

namespace IPTCULMI.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Book> Books { get; set; }
        public DbSet<BorrowLog> BorrowLogs { get; set; }
        public DbSet<ReturnRecord> ReturnRecords { get; set; }

    }
}
