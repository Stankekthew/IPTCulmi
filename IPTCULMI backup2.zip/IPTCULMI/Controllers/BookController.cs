// Controllers/BooksController.cs
using Microsoft.AspNetCore.Mvc;
using IPTCULMI.Data;
using IPTCULMI.Models;
using Microsoft.EntityFrameworkCore;

namespace IPTCULMI.Controllers
{
    public class BooksController : Controller
    {
        private readonly AppDbContext _context;

        public BooksController(AppDbContext context)
        {
            _context = context;
        }

        // GET: /Books
        public async Task<IActionResult> Index()
        {
            var books = await _context.Books.ToListAsync();

            // Get active borrow logs (where ReturnRecord does NOT exist yet)
            var activeBorrows = await _context.BorrowLogs
                .Where(b => !_context.ReturnRecords.Any(r => r.BorrowLogId == b.BorrowLogId)) // Only not returned
                .Select(b => new { b.BookId, b.BorrowLogId })
                .ToListAsync();

            ViewBag.CurrentBorrowLogIds = activeBorrows;

            return View(books);
        }



        // GET: /Books/Create
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Book book)
        {
            if (ModelState.IsValid)
            {
                _context.Books.Add(book);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(book);
        }

        // GET: /Books/Borrow/{id}
        public async Task<IActionResult> Borrow(int id)
        {
            var book = await _context.Books.FindAsync(id);
            if (book == null) return NotFound();

            var model = new BorrowLog { BookId = book.BookId, BookTitle = book.BookTitle };
            return View(model);
        }

        // POST: /Books/Borrow
        [HttpPost]
        public async Task<IActionResult> Borrow(BorrowLog log)
        {
            if (ModelState.IsValid)
            {
                var book = await _context.Books.FindAsync(log.BookId);
                if (book == null || !book.IsAvailable)
                {
                    ModelState.AddModelError("", "Book is not available.");
                    return View(log);
                }

                // Record borrow info
                log.BorrowDate = DateTime.Now;

                // Set expected return date 30 days after borrow date
                log.ReturnDate = log.BorrowDate.AddDays(30);

                _context.BorrowLogs.Add(log);

                // Mark book as unavailable
                book.IsAvailable = false;

                await _context.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return View(log);
        }


        [HttpPost]
        public IActionResult Return(int borrowLogId)
        {
            var borrowLog = _context.BorrowLogs.FirstOrDefault(b => b.BorrowLogId == borrowLogId);
            if (borrowLog == null)
            {
                return NotFound();
            }

            // Create a return record (optional, if you want to log it)
            var returnRecord = new ReturnRecord
            {
                BorrowLogId = borrowLogId,
                ReturnDate = DateTime.Now,
                BookTitle = borrowLog.BookTitle // if you added this property
            };
            _context.ReturnRecords.Add(returnRecord);

            // Update book availability
            var book = _context.Books.FirstOrDefault(b => b.BookId == borrowLog.BookId);
            if (book != null)
            {
                book.IsAvailable = true;
            }

            _context.SaveChanges();

            return RedirectToAction("Index"); // or wherever you want to redirect
        }



    }
}
