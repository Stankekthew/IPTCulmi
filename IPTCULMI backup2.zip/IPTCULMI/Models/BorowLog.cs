namespace IPTCULMI.Models
{
    public class BorrowLog
    {
        public int BorrowLogId { get; set; }
        public int BookId { get; set; }
        public string BookTitle { get; set; } = string.Empty;

        public string Name { get; set; } = string.Empty;
        public string Contact { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;

        public DateTime BorrowDate { get; set; }
        public DateTime? ReturnDate { get; set; }
    }
}